### Expected behavior

### Actual behavior

[//]: # (Besides the text description, include any screenshot(s) that help us visualize the issue you're facing)

### Steps to reproduce the issue
1.
2.
3.

### System information

- result of `kmos version`, operating system, version, python version, possibly link to model file

```

```
[//]: # (If you experienced crashes, segfaults please also include a stacktrace below.)
